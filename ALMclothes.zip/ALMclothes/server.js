//server.js:
const express = require("express");
const app = express();
const port = 3000;
const fs = require("fs");
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const secretKey = "CaldoCotton";


const jsonFilePath = path.join(__dirname,'database.json')


// Importante: Utilizza bodyParser per analizzare i dati del corpo della richiesta
const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(express.static('public'));





app.post("/login", (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    fs.readFile(jsonFilePath, 'utf8', (err, data) => {
        if (err) {
            res.status(500).send("Errore nella lettura del file");
            return;
        }
        if (data) {
            try {
                const info = JSON.parse(data);
                const checkUser = info.users.find(u => u.email === email);

                if (checkUser) {
                    bcrypt.compare(password, checkUser.password, function(err, result) {
                        if (result) {
                            // Password corrisponde, crea il token JWT
                            const token = jwt.sign({ id: checkUser.id, email: checkUser.email }, secretKey, { expiresIn: '1h' });

                            res.json({
                                token, // Invia il token al client
                                id: checkUser.id,
                                name: checkUser.name,
                                surname: checkUser.surname,
                                address: checkUser.address,
                                birthDate: checkUser.birthDate,
                                email: checkUser.email,
                                redirect: 'index.html'
                            });
                        } else {
                            // Password non corrisponde
                            res.status(401).send({ error: "Incorrect email or password" }); 
                        }
                    });
                } else {
                    // Utente non trovato
                    res.status(401).send({ error: "Incorrect email or password" }); 
                }
            } catch (parseError) {
                res.status(500).send("Errore nell'analisi delle credenziali");
            }
        } else {
            res.status(500).send("File JSON vuoto");
        }
    });
});




const saltRounds = 10; // You can adjust the salt rounds as needed

app.post("/register", (req, res) => {
    const name = req.body.name;
    const surname = req.body.surname;
    const address = req.body.address;
    const birthDate = req.body.birthDate;
    const email = req.body.email;
    const password = req.body.password;

    if (name.trim() !== '' && surname.trim() !== '' && address.trim() !== '' && birthDate.trim() !== '' && email.trim() !== '' && password.trim() !== '') {
        fs.readFile(jsonFilePath, 'utf8', (err, data) => {
            if (err) {
                res.status(500).send("Error while reading file");
                return;
            }

            const info = JSON.parse(data);
            const checkUser = info.users.find(u => u.email === email);

            if (!checkUser) {
                // Hash della password prima di salvarla
                bcrypt.hash(password, saltRounds, function(err, hash) {
                    if (err) {
                        res.status(500).send("Error while hashing the password");
                        return;
                    }

                    // Aggiungi l'utente con la password hashata
                    info.users.push({
                        name: name,
                        surname: surname,
                        address: address,
                        birthDate: birthDate,
                        email: email,
                        password: hash, // Storing the hashed password
                        cart: []
                    });

                    // Scrivi nel file JSON
                    fs.writeFile(jsonFilePath, JSON.stringify(info, null, 2), 'utf8', (err) => {
                        if (err) {
                            res.status(500).send("Error while writing to file");
                            return;
                        }
                        res.json({ redirect: 'login.html' });
                    });
                });
            } else {
                res.status(409).send("User already exists");
            }
        });
    } else {
        res.status(400).send("Invalid input");
    }
});


app.get('/products', (req, res) => {
    const gender = req.query.gender;
    const category = req.query.category;

    // Log per mostrare i parametri ricevuti
    console.log("Ricevuti query params:", { gender, category });

    fs.readFile(jsonFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error("Errore nella lettura del file: ", err);
            res.status(500).send("Errore nel server");
            return;
        }

        let info;
        try {
            info = JSON.parse(data);
        } catch (parseError) {
            console.error("Errore nel parsing del JSON:", parseError);
            res.status(500).send("Errore nel parsing del file JSON");
            return;
        }

        // Assicurati che l'oggetto info abbia la proprietà products
        if (!info.products) {
            console.error("Il file JSON non contiene la proprietà 'products'");
            res.status(500).send("Errore nella struttura del file JSON");
            return;
        }

        const filteredProducts = info.products.filter(p => p.category === category && p.gender === gender);

        // Log per mostrare i prodotti filtrati
        console.log("Prodotti filtrati:", filteredProducts);

        if (filteredProducts.length > 0) {
            res.json(filteredProducts);
        } else {
            // Potrebbe essere meglio restituire uno stato 404 qui
            res.status(404).send("Nessun prodotto trovato per i criteri specificati");
        }
    });
});


function verifyToken(req, res, next) {
    const token = req.headers['authorization']; // Assumi che il token sia inviato nell'header 'Authorization'

    if (!token) {
        return res.status(401).send("Token mancante");
    }

    jwt.verify(token, secretKey, (err, decoded) => {
        if (err) {
            return res.status(401).send("Token non valido");
        }

        // Token verificato, aggiungi le informazioni dell'utente alla richiesta
        req.user = decoded;
        next();
    });
}

// Utilizza questa funzione come middleware nelle tue rotte protette
app.get('/someProtectedRoute', verifyToken, (req, res) => {
    // Accedi a req.user per ottenere le informazioni dell'utente
});




app.get("/singleProduct", (req, res) => {
    const id = req.query.id;

    if (!id) {
        res.status(400).send("Missing product ID");
        return;
    }

    fs.readFile(jsonFilePath, 'utf8', (err, data) => {
        if (err) {
            res.status(500).send("Error while reading file");
            return;
        }

        let info;
        try {
            info = JSON.parse(data);
        } catch (parseError) {
            console.error("Error while parsing", parseError);
            res.status(500).send("Error in parsing");
            return;
        }

        const checkProduct = info.products.find(p => p.id === id);

        if (checkProduct) {
            res.send(checkProduct);
        } else {
            res.status(404).send("Product not found");
        }
    });
});

app.post('/singleProduct', (req, res) => {
    const id = req.body.id;
    const email = req.body.email;

    fs.readFile(jsonFilePath, 'utf8', (err, data) => {
        if (err) {
            res.status(500).send("Error reading the file");
            return;
        }

        let info;
        try {
            info = JSON.parse(data);
        } catch (parseError) {
            console.error("Error parsing JSON:", parseError);
            res.status(500).send("Error parsing the JSON file");
            return;
        }

        const checkProduct = info.products.find(p => p.id === id);
        const checkCart = info.users.find(u => u.email === email);

        if (checkProduct && checkCart) {
            // Controlla se la quantità disponibile è sufficiente
            if (checkProduct.quantityAvailable > 0) {
                let productInCart = checkCart.cart.find(item => item.id === checkProduct.id);

                if (productInCart) {
                    // Incrementa la quantità del prodotto nel carrello
                    productInCart.quantity++;
                } else {
                    // Aggiungi il prodotto al carrello
                    checkCart.cart.push({
                        id: checkProduct.id,
                        name: checkProduct.name,
                        img: checkProduct.img,
                        price: checkProduct.price,
                        quantity: 1
                    });
                }

                // Riduci la quantità disponibile del prodotto
                checkProduct.quantityAvailable--;

                // Salva le modifiche
                fs.writeFile(jsonFilePath, JSON.stringify(info, null, 2), 'utf8', (writeErr) => {
                    if (writeErr) {
                        res.status(500).send("Error writing the file");
                        return;
                    }
                    res.json(checkCart.cart);
                });
            } else {
                res.status(400).send("Product is out of stock");
            }
        } else {
            res.status(400).send("Product or cart not found");
        }
    });
});


app.get('/cart', (req, res) => {
    const email = req.query.email; // Cambia da req.body.email a req.query.email

    fs.readFile(jsonFilePath, 'utf-8', (err, data) => {
        if (err) {
            res.status(500).send("Not available");
            return;
        }

        const info = JSON.parse(data);

        const checkUser = info.users.find(u => u.email === email);

        if (checkUser) {
            res.json(checkUser.cart);
        } else {
            res.status(404).send("User not found");
        }
    });
});



app.post('/cart', (req, res) => {
    const email = req.body.email;
    const id = req.body.id;

    console.log("id to remove" + id)

    fs.readFile(jsonFilePath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).send("Error while reading file");
        }

        const info = JSON.parse(data);
        const user = info.users.find(u => u.email === email);

        if (!user) {
            return res.status(404).send("User not found");
        }

        // Rimuovi il prodotto dall'array del carrello
        user.cart = user.cart.filter(item => item.id !== id);

        // Sovrascrivi il file JSON mantenendo la formattazione
        fs.writeFile(jsonFilePath, JSON.stringify(info, null, 2), 'utf8', (err) => {
            if (err) {
                return res.status(500).send("Error while writing file");
            }
            res.send("Product removed from cart");
        });
    });
});









app.listen(3000, ()=>{
    console.log("Connected")
})

















