    fs.readFile("database.json", 'utf8', (err, data) => {
        if (err) {
            // Gestire l'errore di lettura del file
            res.status(500).send("Errore nella lettura del file");
            return;
        }

        if (data) {
            try {
                const info = JSON.parse(data);
                const checkUser = info.users.find(u => u.email === email);

                if(checkUser){
                    res.send("ok");
                } else {
                    res.status(404).send("Utente non trovato");
                }
            } catch (parseError) {
                // Gestire l'errore di analisi del JSON
                res.status(500).send("Errore nell'analisi dei dati JSON");
            }
        } else {
            // Gestire il caso in cui il file è vuoto
            res.status(500).send("File JSON vuoto");
        }
    });
});