//main.js:
const e = require("express");





function redirectToUserPageIfLoggedIn() {
    let token = sessionStorage.getItem('token');
    if (token && window.location.pathname.endsWith('/login.html')) {
        window.location.href = "userPage.html";
    }
}
document.addEventListener('DOMContentLoaded', redirectToUserPageIfLoggedIn);



async function verifyToken(token) {
    try {
        let response = await fetch('/verify-token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        });
        if (response.ok) {
            return true;
        } else {
            return false;
        }
    } catch (error) {
        console.error('Error during token verification:', error);
        return false;
    }
}



function login() {
    document.getElementById('loginForm').addEventListener('submit', function(event) {
        event.preventDefault();

        const email = document.querySelector("#emailValue").value;
        const password = document.querySelector("#passValue").value;

        $.ajax({
            url: 'http://localhost:3000/login',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ email: email, password: password }),

            success: function(data) {
                // Salvare il token JWT nel Local Storage
                sessionStorage.setItem('token', data.token);

                // Altri dati della sessione
                sessionStorage.setItem('name', data.name);
                sessionStorage.setItem('surname', data.surname);
                sessionStorage.setItem('address', data.address);
                sessionStorage.setItem('email', data.email);
                sessionStorage.setItem('password', data.password);

                // Reindirizzamento
                if (data.name === 'admin') {
                    document.location.href = 'admin.html';
                } else {
                    document.location.href = data.redirect;
                }
            },

            error: function() {
                const loginError = document.querySelector('#noUser');
                if (loginError) {
                    loginError.innerText = 'Wrong data';
                    loginError.style.display = 'block';
                } else {
                    error.style.display = 'none'; // Nasconde l'elemento se non ci sono errori
                }
            }
        });
    });
}



function register(){

    document.getElementById('registerForm').addEventListener('submit', function(event){
        event.preventDefault()
    
        const name = document.querySelector("#name").value
        const surname = document.querySelector("#surname").value
        const address = document.querySelector("#address").value
        const birthDate = document.querySelector("#birthDate").value
        const email = document.querySelector("#email").value
        const password = document.querySelector("#password").value

    $.ajax({

        url: 'http://localhost:3000/register',
        method     : 'POST',
        contentType: 'application/json',
        data       : JSON.stringify ({ name: name, surname: surname, address:address, birthDate: birthDate, email:email, password:password }),

        success:function(data){
            document.location.href = data.redirect;
        },

        error: function(){
            const regError = document.querySelector('#alreadyExists')
            if(regError){
                regError.innerText = "User already Exists"
                regError.style.display = "block"
            }
        }
    })    
    
    
       
    
    
    })



}

function changeWelcomeText(){
    const text = document.getElementById('welcomeText')
    if(text){
        currentName = sessionStorage.getItem('name')
        text.innerText = "Welcome Back " + currentName ;
    }
}   

          
function loadProducts(gender, category) {
    $.ajax({
        url: 'http://localhost:3000/products',
        method: 'GET',
        data: { gender: gender, category: category },

        success: function (data) {
            const productSection = document.querySelector('.product-section');

            data.forEach(product => {


                let newProduct = document.createElement('div');
                newProduct.classList.add('product');

                newProduct.dataset.id = product.id;

                newProduct.innerHTML =
                    `<div class="img-prod-container">
                        <a href="singleProduct.html?id=${product.id}" class="chosen">
                            <img src="${product.img}" class="product-image">
                        </a>


                    </div>
                    <a href="singleProduct.html?id=${product.id}" class="chosen"><p class="h3">${product.name}</p></a>
                    <h4>€${product.price}</h4>
                    

                    </div>`;
                productSection.appendChild(newProduct);
            });
        },

        error: function(){
            alert("nu funzion")
        }

    });
}



function logout() {
    // Rimuovere il token dal localStorage
    sessionStorage.removeItem('token');

    // Rimuovere le informazioni dell'utente dalla sessionStorage
    sessionStorage.removeItem('name');
    sessionStorage.removeItem('surname');
    sessionStorage.removeItem('address');
    sessionStorage.removeItem('email');
    sessionStorage.removeItem('password');

    // Reindirizzare l'utente alla pagina di login
    window.location.href = 'login.html';
}

document.getElementById('logoutButton').addEventListener('click', logout);


document.getElementById('logoutButton').addEventListener('click', logout);




let token = localStorage.getItem('token');
fetch('someProtectedRoute', {
    headers: {
        'Authorization': 'Bearer ' + token
    }
})


function loadSingleProduct(productId){

    $.ajax({
            url: `http://localhost:3000/singleProduct?id=${productId}`,
            method: 'GET',

            success: function(data){
             
            let section = document.querySelector('#prodetails')  
            
            let proImg = document.createElement('div');
            proImg.classList.add('single-pro-image');
            proImg.innerHTML = `
            
            <img src="${data.img}" width="100%" id="MainImg" alt="take1">
            `;
            section.appendChild(proImg);

            //Smaller images 
            small_imgs = document.createElement('div');
            small_imgs.classList.add('small-img-group');
            proImg.appendChild(small_imgs);
        
            
            let sm_img_group = document.querySelector('.small-img-group');
                            
            let smImgCol = document.createElement('div');
            smImgCol.classList.add('small-img-col');
            smImgCol.innerHTML = 
            `
            <img src="${data.img}" width="100%" class="small-img" alt="">
            
            `;
            sm_img_group.appendChild(smImgCol);

            let smImgCol1 = document.createElement('div');
            smImgCol1.classList.add('small-img-col');
            smImgCol1.innerHTML = 
            `
            <img src="${data.img}" width="100%" class="small-img" alt="">
            
            `;
            sm_img_group.appendChild(smImgCol1);

            let smImgCol2 = document.createElement('div');
            smImgCol2.classList.add('small-img-col');
            smImgCol2.innerHTML = 
            `
            <img src="${data.img}" width="100%" class="small-img" alt="">
            
            `;
            sm_img_group.appendChild(smImgCol2);

            let smImgCol3 = document.createElement('div');
            smImgCol3.classList.add('small-img-col');
            smImgCol3.innerHTML = 
            `
            <img src="https://tse4.mm.bing.net/th/id/OIG.r3P7pVymysN47CeSsgFZ?w=270&h=270&c=6&r=0&o=5&pid=ImgGn" width="100%" class="small-img" alt="">
            
            `;
            sm_img_group.appendChild(smImgCol3);

            //Product Details
            let proDet = document.createElement('div');
            proDet.classList.add('single-pro-details');
            proDet.dataset.id = data.id;
            proDet.innerHTML = 

            `
                <h6>${data.gender}/${data.category}</h6> 
                <h4>${data.name}</h4>
                <h2>€${data.price}</h2>

                    <select id="prodSize">
                        <option>Select Size</option>
                        <option>XL</option>
                        <option>L</option>
                        <option>M</option>
                        <option>S</option>
                    </select>

                    <button class="addCart" onclick="addToCart(event)">Add To Cart</button>
                    <p id="cartError"></p>            

                    <h4>Description</h4>
                    <span>${data.description}</span>
            `;

            section.appendChild(proDet);

            const smallImages = document.querySelectorAll('.small-img');
            smallImages.forEach(img => {
                img.addEventListener('click', function() {
                    const mainImage = document.getElementById('MainImg');
                    mainImage.src = this.src;
                });
            });


        },
        
        error: function(){
            alert("Product Quantity is over, we'll inform you as soon as possible")
        }

    })

}





function addToCart(event) {
    let productDetails = event.target.closest('.single-pro-details');
    let productId = productDetails.dataset.id;

    $.ajax({
        url: `http://localhost:3000/singleProduct?id=${productId}`,
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ id: productId, email: sessionStorage.getItem('email') }),

        success: function(cartItems) {
            let iconCartSpan = document.querySelector(".quantity-navbar");
            let listCartHTML = document.querySelector('.listCart');
            let subTotContainer = document.querySelector(".subTotal"); 


            listCartHTML.innerHTML = ''; 
            let totalQuantity = 0;
            let newSubTotal = 0;

            cartItems.forEach(item => {
                totalQuantity += item.quantity;
                newSubTotal += item.price * item.quantity;
                let existingCartItem = document.querySelector(`.item[data-id='${item.id}']`);

                if (existingCartItem) {
                    let quantitySpan = existingCartItem.querySelector('.quantity span:nth-child(2)');
                    quantitySpan.textContent = item.quantity; // Aggiorna con la quantità esatta restituita dal server
                } else {
                    let cartDiv = document.createElement('div');
                    cartDiv.classList.add('item');
                    cartDiv.setAttribute('data-id', item.id);
                    cartDiv.innerHTML = `
                        <div class="image">
                            <img src="${item.img}" alt="${item.name}">
                        </div>
                        <div class="name">${item.name}</div>
                        <div class="totalPrice">€${item.price}</div>
                        <div class="quantity">
                            <span class="minus">QNT:</span>
                            <span>${item.quantity}</span>
                            <span class="plus"></span>
                        </div>
                    `;
                    listCartHTML.appendChild(cartDiv);
                }
            });
            localStorage.setItem('cartItems', JSON.stringify(cartItems));
            iconCartSpan.innerText = cartItems.reduce((acc, item) => acc + item.quantity, 0);
            iconCartSpan.innerText = totalQuantity;
            subTotContainer.innerHTML = "SUB TOTAL: €" + newSubTotal;
        },

        error: function() {
            alert("u must be logged into your account to add products")
        }
    });
}








function loadUserCart(userMail){
    if(!userMail){
        alert("Error")
        return
    }

    $.ajax({
        url: `http://localhost:3000/cart?email=${encodeURIComponent(userMail)}`,
        method: 'GET',

        success: function(cart){

            let total = 0;  
            let shippingCost = 0;
            const cartSection = document.querySelector('.cart');
            const cartTable = document.createElement('table');
            cartTable.classList.add('cart');
            cartTable.innerHTML = 
                `
                    <thead>
                        <tr>
                            <td>ID</td>
                            <td>Product</td>
                            <td>Price</td>
                            <td>Quantity</td>
                            <td>Remove</td>                   
                        </tr>
                    </thead>
                    <tbody id="bodyTable">
                    </tbody> 
                `;

                cartSection.innerHTML = '';
                cartSection.appendChild(cartTable);
                const tableBody = cartTable.querySelector('tbody');

                let totalContainer = document.querySelector('#totalOfCart');
                let shippingContainer = document.querySelector("#shCosts");
                let finalContainer = document.querySelector('#total');
                          
                cart.forEach(item => {
                    
                    const row = document.createElement('tr');
                    row.dataset.productId = item.id;
                    row.innerHTML = `
                        <td><img src="${item.img}"></td>
                        <td>${item.name}</td>
                        <td>${item.price * item.quantity}</td>
                        <td>${item.quantity}</td>
                        <td class="trashBin"><button onclick="removeItem(event)" style="border:none; background-color:white;"><i class="fa-solid fa-trash-can"></button></i></td>
                    `;
                    tableBody.appendChild(row);
                    total += item.price * item.quantity
                    
                });
                localStorage.setItem('cartItems', JSON.stringify(cart));

                totalContainer.innerHTML = '€' + total
                if(total>50){
                    shippingCost = 4
                }else{
                    shippingCost = 0
                }
                shippingContainer.innerHTML = '€' + shippingCost
                finalContainer.innerHTML = '€' + (total + shippingCost);
        },

        error: function(){
            alert("not ok")

        }
    })

}




function removeItem(event) {
    const row = event.target.closest('tr'); // Ottiene la riga del bottone cliccato
    const productId = row.dataset.productId; // Ottiene l'ID del prodotto
    const email = sessionStorage.getItem('email');

    $.ajax({
        url: 'http://localhost:3000/cart',
        method     : 'POST',
        contentType: 'application/json',
        data       : JSON.stringify({ id: productId, email: email }),

        success: function() {
            // Ricarica la pagina
            location.reload();
        },
        error: function() {
            alert("Errore nell'eliminazione del prodotto dal carrello");
        }
    });
}




//this function is used to load the cart content in the other pages of the webApp
function loadCartContent(email) {

    if(email){
    let listCartHTML = document.querySelector(".listCart");
    let iconCartSpan = document.querySelector(".quantity-navbar");
    let subTotContainer = document.querySelector(".subTotal"); 

    if (!listCartHTML || !iconCartSpan || !subTotContainer) {
        console.error("Uno o più elementi del DOM non trovati.");
        return;
    }

    listCartHTML.innerHTML = ''; 
    let totalQuantity = 0;
    let newSubTotal = 0;

    let storedCartItems = localStorage.getItem('cartItems')
    if(storedCartItems){

        let cartItems = JSON.parse(storedCartItems)

        cartItems.forEach(item => {
            totalQuantity += item.quantity;
            newSubTotal += item.price * item.quantity;
        
            let newCart = document.createElement('div');
            newCart.classList.add('item');
            newCart.dataset.id = item.product_id;
            newCart.innerHTML = `
                <div class="image">
                    <img src="${item.img}">
                </div>
                <div class="name">
                    ${item.name}
                </div>
                <div class="totalPrice">
                    €${item.price * item.quantity}
                </div>
                <span>QNT: ${item.quantity}</span>
            `;
            listCartHTML.appendChild(newCart);
        });
        

    }else{
        console.log("No elements")
    }
    iconCartSpan.innerText = totalQuantity;
    subTotContainer.innerHTML = "SUB TOTAL: €" + newSubTotal;
    }else{
        console.log("U must be logged in")
    }
}



function loadCartContent(email) {

    if(email){
    let listCartHTML = document.querySelector(".listCart");
    let iconCartSpan = document.querySelector(".quantity-navbar");
    let subTotContainer = document.querySelector(".subTotal"); 

    if (!listCartHTML || !iconCartSpan || !subTotContainer) {
        console.error("Uno o più elementi del DOM non trovati.");
        return;
    }

    listCartHTML.innerHTML = ''; 
    let totalQuantity = 0;
    let newSubTotal = 0;

    let storedCartItems = localStorage.getItem('cartItems')
    if(storedCartItems){

        let cartItems = JSON.parse(storedCartItems)

        cartItems.forEach(item => {
            totalQuantity += item.quantity;
            newSubTotal += item.price * item.quantity;
        
            let newCart = document.createElement('div');
            newCart.classList.add('item');
            newCart.dataset.id = item.product_id;
            newCart.innerHTML = `
                <div class="image">
                    <img src="${item.img}">
                </div>
                <div class="name">
                    ${item.name}
                </div>
                <div class="totalPrice">
                    €${item.price * item.quantity}
                </div>
                <span>QNT: ${item.quantity}</span>
            `;
            listCartHTML.appendChild(newCart);
        });
        

    }else{
        console.log("No elements")
    }
    iconCartSpan.innerText = totalQuantity;
    subTotContainer.innerHTML = "SUB TOTAL: €" + newSubTotal;
    }else{
        console.log("U must be logged in")
    }
}



function loadCartContentV2(email) {
    if (email) {
        let iconCartSpan = document.querySelector(".quantity-navbar");

        if (!iconCartSpan) {
            console.error("Elemento .quantity-navbar non trovato.");
            return;
        }

        let totalQuantity = 0;
        let storedCartItems = localStorage.getItem('cartItems');

        if (storedCartItems) {
            let cartItems = JSON.parse(storedCartItems);
            cartItems.forEach(item => {
                totalQuantity += item.quantity;
            });
        } else {
            console.log("Nessun elemento nel carrello.");
        }

        iconCartSpan.innerText = totalQuantity;

        } else {
            console.log("Devi essere loggato.");
        }
}
















