//main.js:

function redirectToUserPageIfLoggedIn() {
    let token = localStorage.getItem('token');
    if (token && window.location.pathname.endsWith('/login.html')) {
        window.location.href = "userPage.html";
    }
}
document.addEventListener('DOMContentLoaded', redirectToUserPageIfLoggedIn);
/*
function redirectToLoginIfNotLoggedIn() {
    let token = localStorage.getItem('token');
    if (!token) {
        window.location.href = "login.html";
    } else {
        // Opzionalmente, verifica il token con il server qui
    }
}
document.addEventListener('DOMContentLoaded', redirectToLoginIfNotLoggedIn);
*/
// Esegui questa funzione non appena la pagina viene caricata

/*function checkAlreadyLogged() {
    let token = localStorage.getItem('token');
    if (token && window.location.pathname === '/login.html') {
        // Se c'è un token e l'utente è sulla pagina di login, verifica la sua validità
        verifyToken(token).then(isValid => {
            if (isValid) {
                // Se il token è valido, reindirizza l'utente a userPage.html
                window.location.href = "userPage.html";
            }
        });
    }
}*/



//starts automatically when the page is loaded and checks if the user is logged
/*
function checkNotLogged() {
    let token = localStorage.getItem('token');
    if (!token) {
        // Se non c'è un token e l'utente non è già sulla pagina di login, reindirizzalo
        if (window.location.pathname !== '/login.html') {
            document.location.href = "login.html";
        }
    } else {
        // Opzionalmente, puoi verificare la validità del token inviandolo al server
        verifyToken(token).then(isValid => {
            if (!isValid) {
                localStorage.removeItem('token');
                if (window.location.pathname !== '/login.html') {
                    document.location.href = "login.html";
                }
            } else {
                // Se l'utente è già sulla pagina di userPage, non fare nulla, altrimenti reindirizza
                if (window.location.pathname !== '/userPage.html') {
                    document.location.href = "userPage.html";
                }
            }
        });
    }
}
*/

async function verifyToken(token) {
    try {
        let response = await fetch('/verify-token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        });
        if (response.ok) {
            return true;
        } else {
            return false;
        }
    } catch (error) {
        console.error('Error during token verification:', error);
        return false;
    }
}



function login() {
    document.getElementById('loginForm').addEventListener('submit', function(event) {
        event.preventDefault();

        const email = document.querySelector("#emailValue").value;
        const password = document.querySelector("#passValue").value;

        $.ajax({
            url: 'http://localhost:3000/login',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ email: email, password: password }),

            success: function(data) {
                // Salvare il token JWT nel Local Storage
                localStorage.setItem('token', data.token);

                // Altri dati della sessione
                sessionStorage.setItem('name', data.name);
                sessionStorage.setItem('surname', data.surname);
                sessionStorage.setItem('address', data.address);
                sessionStorage.setItem('email', data.email);
                sessionStorage.setItem('password', data.password);

                // Reindirizzamento
                if (data.name === 'admin') {
                    document.location.href = 'admin.html';
                } else {
                    document.location.href = data.redirect;
                }
            },

            error: function() {
                const loginError = document.querySelector('#noUser');
                if (loginError) {
                    loginError.innerText = 'Wrong data';
                    loginError.style.display = 'block';
                } else {
                    error.style.display = 'none'; // Nasconde l'elemento se non ci sono errori
                }
            }
        });
    });
}



function register(){

    document.getElementById('registerForm').addEventListener('submit', function(event){
        event.preventDefault()
    
        const name = document.querySelector("#name").value
        const surname = document.querySelector("#surname").value
        const address = document.querySelector("#address").value
        const birthDate = document.querySelector("#birthDate").value
        const email = document.querySelector("#email").value
        const password = document.querySelector("#password").value

    $.ajax({

        url: 'http://localhost:3000/register',
        method     : 'POST',
        contentType: 'application/json',
        data       : JSON.stringify ({ name: name, surname: surname, address:address, birthDate: birthDate, email:email, password:password }),

        success:function(data){
            document.location.href = data.redirect;
        },

        error: function(){
            const regError = document.querySelector('#alreadyExists')
            if(regError){
                regError.innerText = "User already Exists"
                regError.style.display = "block"
            }
        }
    })    
    
    
       
    
    
    })



}

function changeWelcomeText(){
    const text = document.getElementById('welcomeText')
    if(text){
        currentName = sessionStorage.getItem('name')
        text.innerText = "Welcome Back " + currentName + "!";
    }
}   

          
function loadProducts(gender, category) {
    $.ajax({
        url: 'http://localhost:3000/products',
        method: 'GET',
        data: { gender: gender, category: category },

        success: function (data) {
            const productSection = document.querySelector('.product-section');

            data.forEach(product => {


                let newProduct = document.createElement('div');
                newProduct.classList.add('product');

                newProduct.dataset.id = product.id;

                newProduct.innerHTML =
                    `<div class="img-prod-container">
                        <a href="singleProduct.html?id=${product.id}" class="chosen">
                            <img src="${product.img}" class="product-image">
                        </a>


                    </div>
                    <a href="singleProduct.html?id=${product.id}" class="chosen"><p>${product.name}</p></a>
                    <h2>€${product.price}</h2>
                    

                    </div>`;
                productSection.appendChild(newProduct);
            });
        },

        error: function(){
            alert("nu funzion")
        }

    });
}



function logout() {
    // Rimuovere il token dal localStorage
    localStorage.removeItem('token');

    // Rimuovere le informazioni dell'utente dalla sessionStorage
    sessionStorage.removeItem('name');
    sessionStorage.removeItem('surname');
    sessionStorage.removeItem('address');
    sessionStorage.removeItem('email');
    sessionStorage.removeItem('password');

    // Reindirizzare l'utente alla pagina di login
    window.location.href = 'login.html';
}

document.getElementById('logoutButton').addEventListener('click', logout);


document.getElementById('logoutButton').addEventListener('click', logout);




let token = localStorage.getItem('token');
fetch('someProtectedRoute', {
    headers: {
        'Authorization': 'Bearer ' + token
    }
})


function loadSingleProduct(productId){

    $.ajax({
            url: `http://localhost:3000/singleProduct?id=${productId}`,
            method: 'GET',

            success: function(data){
             
            let section = document.querySelector('#prodetails')  
            
            let proImg = document.createElement('div');
            proImg.classList.add('single-pro-image');
            proImg.innerHTML = `
            
            <img src="${data.img}" width="100%" id="MainImg" alt="take1">
            `;
            section.appendChild(proImg);

            /*Smaller images */

            //Product Details
            let proDet = document.createElement('div');
            proDet.classList.add('single-pro-details');
            proDet.dataset.id = data.id;
            proDet.innerHTML = 

            `
                <h6>${data.gender}/${data.category}</h6> 
                <h4>${data.name}</h4>
                <h2>€${data.price}</h2>

                    <select id="prodSize">
                        <option>Select Size</option>
                        <option>XL</option>
                        <option>L</option>
                        <option>M</option>
                        <option>S</option>
                    </select>

                    <button class="addCart" onclick="addToCart(event)">Add To Cart</button>
                    <p id="cartError"></p>            

                    <h4>Description</h4>
                    <span>${data.description}</span>
            `;

            section.appendChild(proDet);
        },
        
        error: function(){
            alert("nu funzion")
        }

    })

}





function addToCart(event) {
    let productDetails = event.target.closest('.single-pro-details');
    let productId = productDetails.dataset.id;

    $.ajax({
        url: `http://localhost:3000/singleProduct?id=${productId}`,
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ id: productId, email: sessionStorage.getItem('email') }),

        success: function(cartItems) {
            let iconCartSpan = document.querySelector(".quantity-navbar");
            let listCartHTML = document.querySelector('.listCart');

            cartItems.forEach(item => {
                let existingCartItem = document.querySelector(`.item[data-id='${item.id}']`);

                if (existingCartItem) {
                    let quantitySpan = existingCartItem.querySelector('.quantity span:nth-child(2)');
                    quantitySpan.textContent = item.quantity; // Aggiorna con la quantità esatta restituita dal server
                } else {
                    let cartDiv = document.createElement('div');
                    cartDiv.classList.add('item');
                    cartDiv.setAttribute('data-id', item.id);
                    cartDiv.innerHTML = `
                        <div class="image">
                            <img src="${item.img}" alt="${item.name}">
                        </div>
                        <div class="name">${item.name}</div>
                        <div class="totalPrice">€${item.price}</div>
                        <div class="quantity">
                            <span class="minus"><</span>
                            <span>${item.quantity}</span>
                            <span class="plus">></span>
                        </div>
                        <div class="trashBin">
                            <i class="fa-solid fa-trash-can"></i>
                        </div>
                    `;
                    listCartHTML.appendChild(cartDiv);
                }
            });
            sessionStorage.setItem('cartItems', JSON.stringify(cartItems));
            iconCartSpan.innerText = cartItems.reduce((acc, item) => acc + item.quantity, 0);
        },

        error: function() {
            alert("Errore nella richiesta AJAX");
        }
    });
}








function loadUserCart(userMail){
    if(!userMail){
        alert("Error")
        return
    }

    $.ajax({
        url: `http://localhost:3000/cart?email=${encodeURIComponent(userMail)}`,
        method: 'GET',

        success: function(cart){

            let total = 0;  
            let shippingCost = 0;
            const cartSection = document.querySelector('.cart');
            const cartTable = document.createElement('table');
            cartTable.classList.add('cart');
            cartTable.innerHTML = 
                `
                    <thead>
                        <tr>
                            <td>ID</td>
                            <td>Product</td>
                            <td>Price</td>
                            <td>Quantity</td>
                            <td>Remove</td>                   
                        </tr>
                    </thead>
                    <tbody id="bodyTable">
                    </tbody> 
                `;

                cartSection.innerHTML = '';
                cartSection.appendChild(cartTable);
                const tableBody = cartTable.querySelector('tbody');

                let totalContainer = document.querySelector('#totalOfCart');
                let shippingContainer = document.querySelector("#shCosts");
                let finalContainer = document.querySelector('#total');
                          
                cart.forEach(item => {
                    
                    const row = document.createElement('tr');
                    row.dataset.productId = item.product_id;
                    row.innerHTML = `
                        <td><img src="${item.img}"></td>
                        <td>${item.name}</td>
                        <td>${item.price * item.quantity}</td>
                        <td>${item.quantity}</td>
                        <td class="trashBin"><i class="fa-solid fa-trash-can"></i></td>
                    `;
                    tableBody.appendChild(row);
                    total += item.price * item.quantity
                    
                });

                totalContainer.innerHTML = '€' + total
                if(total>50){
                    shippingCost = 4
                }else{
                    shippingCost = 0
                }
                shippingContainer.innerHTML = '€' + shippingCost
                finalContainer.innerHTML = '€' + (total + shippingCost);
        },

        error: function(){
            alert("not ok")

        }
    })

}

//this function is used to load the cart content in the other pages of the webApp
function loadCartContent(email) {

    if(email){
    let listCartHTML = document.querySelector(".listCart");
    let iconCartSpan = document.querySelector(".quantity-navbar");
    let subTotContainer = document.querySelector(".subTotal"); 

    if (!listCartHTML || !iconCartSpan || !subTotContainer) {
        console.error("Uno o più elementi del DOM non trovati.");
        return;
    }

    listCartHTML.innerHTML = ''; 
    let totalQuantity = 0;
    let newSubTotal = 0;

    let storedCartItems = sessionStorage.getItem('cartItems')
    if(storedCartItems){

        let cartItems = JSON.parse(storedCartItems)

        cartItems.forEach(item => {
            totalQuantity += item.quantity;
            newSubTotal += item.price * item.quantity;
        
            let newCart = document.createElement('div');
            newCart.classList.add('item');
            newCart.dataset.id = item.product_id;
            newCart.innerHTML = `
                <div class="image">
                    <img src="${item.img}">
                </div>
                <div class="name">
                    ${item.name}
                </div>
                <div class="totalPrice">
                    €${item.price * item.quantity}
                </div>
                <span>QNT: ${item.quantity}</span>
            `;
            listCartHTML.appendChild(newCart);
        });
        

    }else{
        console.log("No elements")
    }
    iconCartSpan.innerText = totalQuantity;
    subTotContainer.innerHTML = "SUB TOTAL: €" + newSubTotal;
    }else{
        console.log("U must be logged in")
    }
}



function loadCartContent(email) {

    if(email){
    let listCartHTML = document.querySelector(".listCart");
    let iconCartSpan = document.querySelector(".quantity-navbar");
    let subTotContainer = document.querySelector(".subTotal"); 

    if (!listCartHTML || !iconCartSpan || !subTotContainer) {
        console.error("Uno o più elementi del DOM non trovati.");
        return;
    }

    listCartHTML.innerHTML = ''; 
    let totalQuantity = 0;
    let newSubTotal = 0;

    let storedCartItems = sessionStorage.getItem('cartItems')
    if(storedCartItems){

        let cartItems = JSON.parse(storedCartItems)

        cartItems.forEach(item => {
            totalQuantity += item.quantity;
            newSubTotal += item.price * item.quantity;
        
            let newCart = document.createElement('div');
            newCart.classList.add('item');
            newCart.dataset.id = item.product_id;
            newCart.innerHTML = `
                <div class="image">
                    <img src="${item.img}">
                </div>
                <div class="name">
                    ${item.name}
                </div>
                <div class="totalPrice">
                    €${item.price * item.quantity}
                </div>
                <span>QNT: ${item.quantity}</span>
            `;
            listCartHTML.appendChild(newCart);
        });
        

    }else{
        console.log("No elements")
    }
    iconCartSpan.innerText = totalQuantity;
    subTotContainer.innerHTML = "SUB TOTAL: €" + newSubTotal;
    }else{
        console.log("U must be logged in")
    }
}



function loadCartContentV2(email) {
    if (email) {
        let iconCartSpan = document.querySelector(".quantity-navbar");

        if (!iconCartSpan) {
            console.error("Elemento .quantity-navbar non trovato.");
            return;
        }

        let totalQuantity = 0;
        let storedCartItems = sessionStorage.getItem('cartItems');

        if (storedCartItems) {
            let cartItems = JSON.parse(storedCartItems);
            cartItems.forEach(item => {
                totalQuantity += item.quantity;
            });
        } else {
            console.log("Nessun elemento nel carrello.");
        }

        iconCartSpan.innerText = totalQuantity;
    } else {
        console.log("Devi essere loggato.");
    }
}
















