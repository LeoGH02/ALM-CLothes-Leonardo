

const body = document.querySelector("body");



const openShopping = document.querySelector(".shopping");
const closeShopping = document.querySelector(".closeShopping")


openShopping.addEventListener("click", () => {

    document.body.classList.add("active");

});

closeShopping.addEventListener("click", () => {

    document.body.classList.remove("active");

});





























